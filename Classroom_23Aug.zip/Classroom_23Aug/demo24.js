// Constructor
class Customer{
    constructor() {
        console.log("constructor is called");
    }
}


let c1 = new Customer();
let c2 = new Customer();

