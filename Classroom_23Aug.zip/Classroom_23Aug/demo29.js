class BankAccount{
    constructor(cname, amount=0) {
        var day = new Date().getDay();
        this.cname = cname;
        this.accountBalance=0;
        if(day==0){
            console.log(`Congrats ${this.cname}, You got opening Balance`);
            this.accountBalance=500;
        }
        
        this.accountBalance += amount;
    }

    deposit(amount){
        var hours = new Date().getHours();
        var day = new Date().getDay();

        if (day==0){
            console.log(`Status failed: Cannot deposit on sunday`);
        }else if(hour<10 || hour>17){
            console.log(`Status failed: Cannot deposit out of office hours`);
        }else{
            this.accountBalance += amount;
            console.log(`Success:${amount} depositted successfully`);
        }
    }

    withdraw(amount){
        var hours = new Date().getHours();
        var day = new Date().getDay();

        if (amount==0){
            console.log(`Status failed: Cannot Withdraw as fund is 0`);
        }else if(this.accountBalance<amount){
            console.log(`Status failed: Cannot Withdraw as fund is less than amount`);
        }else if (day==0){
            console.log(`Status failed: Cannot deposit on sunday`);
        }else if(hour<10 || hour>17){
            console.log(`Status failed: Cannot deposit out of office hours`);
        }else{
            this.accountBalance += amount;
            console.log(`Success:${amount} depositted successfully`);
        }
    }

    getDetails(){
        console.log(`CName: ${this.cname}`);
        console.log(`Balance : ${this.accountBalance}`);
    }
}

let customer1 =new BankAccount("Sarfaraz",80000);
let customer2 =new BankAccount("Kamran");

customer1.getDetails();
customer2.getDetails();
customer1.deposit(6000);
customer1.getDetails();
customer1.withdraw(100000);
customer1.getDetails();
