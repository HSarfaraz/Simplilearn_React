// Parameterised arrow function
let wishes = name => console.log(`Hello ${name}`);

wishes("Sarfaraz");
wishes("Hussain");
