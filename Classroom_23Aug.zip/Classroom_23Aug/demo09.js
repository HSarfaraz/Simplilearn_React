// Arrow function returning a parameter
let square = n => n*n;

let add = (a,b) => a+b;

let big = (a,b) => a>b?a:b;

console.log(square(5));
console.log(add(5,6));
console.log(big(5,6));