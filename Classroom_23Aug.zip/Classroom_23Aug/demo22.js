// Destructuring
let companies = ['Compugain','Karvy','Trianz','TEKSystems'];

let company1, company2, rest;

[company1, company2, ...rest] = companies;

console.log(company1);
console.log(company2);
console.log(rest);

// Example 2
let emp = {"id":1001,"ename":"Sarfaraz","job":"Developer","salary":5000};
let {ename, job} = emp;
console.log(ename+" "+job);