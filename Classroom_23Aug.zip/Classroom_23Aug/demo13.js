var fruits = require("./demo12").fruits;
var vegitables = require("./demo12").vegitables;


fruits.forEach( item => console.log(item));
vegitables.forEach( function(item) { console.log(item)});