let fruits = ['Apple','Banana'];
let fruits1 = fruits.map(x => x.toUpperCase());

console.log(fruits);
console.log(fruits1);