function drawLine(){
    var msg = "";
    for(let i=1;i<80;i++)
        msg+='-';
    console.log(msg);
}

function wishes(){
    let hour = new Date().getHours();
    if(hour<12) console.log('Good morning');
    else if(hour<6) console.log('Good Afternoon');
    else console.log('Good Evening');
}
drawLine();
wishes();
drawLine();
