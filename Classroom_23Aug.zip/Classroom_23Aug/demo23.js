// OOJ
class Test{
    display(){
        console.log("Hello from test");
    }
}

let testObject = new Test();
testObject.display();