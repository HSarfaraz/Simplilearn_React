module.exports.square = n => n*n;
module.exports.add = (a,b) => (a,b);
module.exports.big = (a,b) => a>b?a:b;