// Static methods
class Calculations{
    static square(n){
        return n*n;
    }
    static addition(a,b){
        return a+b;
    }
    static big(a,b){
        return a>b?a:b;
    }
}

console.log(Calculations.square(5))
console.log(Calculations.addition(5,4))
console.log(Calculations.big(5,4))