let square = require("./demo10").square;
console.log(square(5));

let mathModule = require("./demo10");
console.log(mathModule.add(5,6));
console.log(mathModule.big(5,6));