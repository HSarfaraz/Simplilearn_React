// How to pass an argument in the function

function display(name){
    console.log(`Hello ${name}`)
};

display('Sarfaraz');
display('Hussain');