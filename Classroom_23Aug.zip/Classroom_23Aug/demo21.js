// Rest operator demo
function display(trainer,...students){
    console.log(`Trainer name: ${trainer}`)
    console.log(`Student name: ${students}`)
}

var batch1  = ["Sarfaraz","Kamran"];
var batch2  = ["Rahul","Raju"];

display("Hussain", batch1, batch2);