module.exports.fruits = ['Apple','Banana','Cherry'];
module.exports.vegitables = ['Onion','Potato','Tomato'];
