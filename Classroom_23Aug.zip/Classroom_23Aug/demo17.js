module.exports = [
    {"id":1001,"ename":"Sarfaraz","job":"Developer","salary":2500},
    {"id":1002,"ename":"Akshata","job":"Tester","salary":7500},
    {"id":1003,"ename":"Kamran","job":"DevOps","salary":8500},
    {"id":1004,"ename":"Hussain","job":"Developer","salary":3500},
    {"id":1005,"ename":"Parvez","job":"Tester","salary":6500},
    {"id":1006,"ename":"Rahul","job":"DevOps","salary":7500},
];