var batch1 = ['Sarfaraz','Kamran','Rizwan'];

//Create reference variable but not create the duplicate 
var batch2 = batch1;

batch1[batch1.length] = 'Naveed';
batch2[batch2.length] = 'Mirza';

console.log(batch1);
console.log(batch2);