// FE: Function expression
//Type of function where function can be assign to a variable
//Adv: exported as a function argument to another function

var f1 = function(){
    console.log("Hello from F1");
}
f1();

var f2 = function(name){
    console.log(`Hello ${name}, Welcome to FE with parameter`);
}
f2("Sarfaraz");


var f3 = function(n){
    return n*n;
}
console.log(f3(8));