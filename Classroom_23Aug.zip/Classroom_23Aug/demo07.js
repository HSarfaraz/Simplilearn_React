// Arrow functions
let display = () => console.log("Hello from Arrow function");
display();