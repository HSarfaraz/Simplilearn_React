module.exports = [
        {"id":1001,"ename":"Sarfaraz","job":"Developer","salary":5500},
        {"id":1002,"ename":"Akshata","job":"Tester","salary":6500},
        {"id":1003,"ename":"Kamran","job":"DevOps","salary":7500},
];