// Mathematical functions

function square(n){
    return n*n;
}

function addition(a,b){
    return a+b;
}

console.log(square(5));
console.log(addition(10,25));