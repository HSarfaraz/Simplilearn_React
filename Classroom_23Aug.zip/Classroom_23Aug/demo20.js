// Spread operator: It creates the duplicate
//Used to spread the variable to items

var batch1 = ['Sarfaraz',1001,'Rizwan'];

//Create the duplicate 
var batch2 = [...batch1];

if(batch1==batch2){
    console.log("Same")
}else
    console.log("Not same");


if( JSON.stringify ( batch1 ) == JSON.stringify ( batch2 )){
    console.log("Same");
    // console.log(batch1);
    // console.log(batch2);
    // console.log(JSON.stringify(batch1));
    // console.log(JSON.stringify(batch2));
}else
    console.log("Not same");


// batch1[batch1.length] = 'Naveed';
// batch2[batch2.length] = 'Mirza';

console.log(batch1);
console.log(batch2);

