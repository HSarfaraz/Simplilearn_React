// set and get function
class Customer{
    setDetails(cname, city){
        this.cname=cname;
        this.city=city;
    }
    getDetails(){
        console.log(`Name: ${this.cname}, City: ${this.city}`)
    }
}


let c1 = new Customer();
c1.setDetails("Sarfaraz","Hyderabad");
c1.getDetails();

