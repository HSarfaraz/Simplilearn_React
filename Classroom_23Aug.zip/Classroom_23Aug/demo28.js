setInterval(()=>{
    console.log(`Time ${new Date().toLocaleString()}`)
},1000);