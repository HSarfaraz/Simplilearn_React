//Depend on demo05
var myModule = require('./demo05');
myModule.sayHello();
myModule.wishes("Sarfaraz");
myModule.sayHello("Hussain");
console.log(myModule.square(5));
console.log(myModule.big(5,3));