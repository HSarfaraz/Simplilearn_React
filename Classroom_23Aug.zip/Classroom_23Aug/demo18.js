var em = require("./demo15");

var employees = em.filter(employee=>employee.job=="Developer");
employees.forEach(
  employee => console.log(employee)
);

// Find
var findRecord = em.find(employee=>employee.id==1002);
console.log(findRecord);

// FindIndex
var findRecordIndex = em.findIndex(employee=>employee.id==1005);
console.log(findRecordIndex);

// some
var isEligibleForLoan = em.some(emp=>emp.salary>=3000);
    console.log(isEligibleForLoan);
