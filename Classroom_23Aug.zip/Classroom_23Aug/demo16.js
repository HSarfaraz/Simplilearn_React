var employees = require("./demo15");

var names = employees.map(x=>x.ename);
names.forEach(name => console.log(name));