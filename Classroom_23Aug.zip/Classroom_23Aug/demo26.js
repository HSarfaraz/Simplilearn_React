class Employee{
    constructor(id,ename, job,salary) {
        this.id=id;
        this.ename=ename;
        this.job=job;
        this.salary = salary;
    }
    getDetails(){
        console.log(`${this.id} ${this.ename} ${this.job} ${this.salary}`)
    }
}

let emp1 = new Employee(1001,"Sarfaraz","Developer",5000);
let emp2 = new Employee(1002,"Vikram","Architecht",8000);

emp1.getDetails();
emp2.getDetails();