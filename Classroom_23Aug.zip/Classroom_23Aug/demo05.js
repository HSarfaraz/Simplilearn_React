// Contain all functions which are exported for demo06
module.exports.sayHello = function(){
    console.log(`Hello from FE in module`);
}

module.exports.wishes = function(name){
    console.log(`Hello ${name}`)
}

module.exports.square = function(n){
    return n*n;
}

module.exports.big = function(a,b){
    return a>b?a:b;
}