// Array with different datatypes
let items = [100, "Sarfaraz", new Date(), true, function(){}, [10,20,30]];

for(let i in items)
    console.log(`items[${i}] = ${items[i]}, datatype is: ${typeof items[i]}`);