// How to handle multiple items

var employees = [
    {"id":1001, "ename":"Sarfaraz","job":"Trainer","salary":5500},
    {"id":1002, "ename":"Hussain","job":"Developer","salary":6500},
    {"id":1003, "ename":"Sohail","job":"Trainer","salary":7500},
    {"id":1004, "ename":"Salman","job":"Programmer","salary":8500}
];

// 1st way of itteration
for(var i=0; i<employees.length;i++){
    var e=employees[i];
    console.log(`${e.id} ${e.ename} ${e.job} ${e.salary}`);
}


employees.unshift({"id":1000,"ename":"Ashok","job":"Developer","salary":8900});
employees.push({"id":1005,"ename":"Fernandez","job":"Developer","salary":8900});
// 2nd way of itteration
for(let e of employees)
    console.log(`${e.id} ${e.job} ${e.ename} ${e.salary}`)