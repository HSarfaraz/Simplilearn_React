// Operations on arrays
var items = ['pen','eraser','scale','baloon'];

// Using predefined methods to manipulate
console.log(items);
items.push('stapler'); //Add item at last
console.log(items);
items.unshift('paper'); //Add item to the first
console.log(items);
items.pop(); //remove last item
console.log(items);
items.shift(); //Remove first items
console.log(items);