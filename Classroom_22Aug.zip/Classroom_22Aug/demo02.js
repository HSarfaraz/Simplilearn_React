var v1=100;
console.log("v1= "+v1+" , data type is "+typeof v1);
var v2="Sarfaraz";
console.log("v2= "+v2+" , data type is "+typeof v2);
var v3=true;
console.log("v3= "+v3+" , data type is "+typeof v3);
var v4;
console.log("v4= "+v4+" , data type is "+typeof v4);