module.exports.fruits = ['Apple','Banana','Cherry'];
module.exports.vegitables = ['Onion','Tomato','Potato'];