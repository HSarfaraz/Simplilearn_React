var name ="Sarfaraz Hussain"

// Task: Display all letters excluding last letter
console.log(`Excluding last letter:${name.substr(0, name.length-1)}`);

// Task: Disply all letter excluding first letter
console.log(`Excluding first letter: ${name.substr(1)}`);

//Task: Display first name in full name
console.log(`First Name is: ${name.substr(0,name.indexOf(' ')-1)}`);

//Task: Display last name in full name
console.log(`Lat Name is: ${name.substr(name.lastIndexOf(' ')+1)}`);