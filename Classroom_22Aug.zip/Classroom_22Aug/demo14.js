module.exports.heading = 'React Training';
module.exports.trainer = 'Sarfaraz Hussain';