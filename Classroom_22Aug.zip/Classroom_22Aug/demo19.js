var employees = require("./demo18").employees;


for(let e of employees)
    console.log(e)