// While loop

//var i=1;

// For loop
for(let i=1;i<=10;i++)
    console.log(i); //Display 1 to 10
console.log("test"+i); //Error; i is not defined


