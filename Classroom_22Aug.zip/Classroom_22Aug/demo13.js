// Exporting a module

var module1 = require("./demo14");

console.log(module1.heading);
console.log(module1.trainer);