function sayHello(){
    console.log("Hello from functions!");
}

sayHello();