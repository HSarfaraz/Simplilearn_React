// JSON Object
var emp = {
    "id": 1001,
    "ename":"Sarfaraz",
    "job":"Employee",
    "salary":75000
}

console.log(emp);
console.log(emp.id);
console.log(emp.ename);
console.log(emp.job);
console.log(emp.salary);

for(let i in emp)
    console.log(`${i} = ${emp[i]}`);