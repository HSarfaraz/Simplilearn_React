// Arrays
// Array with Similar datatypes

var items = ['pen','pencil','eraser','sharpner'];

console.log(items);

console.log(items[0]);
console.log(items[1]);
console.log(items.length);
console.log(items[items.length-1]);


// Iteration of Arrays
let itemslist = ['pen','pencil','eraser','sharpner'];

itemslist[itemslist.length] = 'paper';

// 1st way of array iteration
// for(let i=0;i<itemslist.length;i++)
//     console.log(itemslist);

// 2nd way of array iteration
// for(let item of itemslist)
//     console.log(item);

// 3rd way of array iteration
for(let i in itemslist)
    console.log(`itemslist[${i}] = ${itemslist[i]}`);