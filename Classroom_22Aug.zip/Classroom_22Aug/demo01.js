// console.log('Hello World');

//console.log(name);
const name = "Sarfaraz";
console.log(name);
name = "Hussain";