//Other way of accessing the module
var fruits = require("./demo16").fruits;
var vegitables = require("./demo16").vegitables;


for(let fruit of fruits)
    console.log(fruit)

for(let veg of vegitables)
    console.log(veg)