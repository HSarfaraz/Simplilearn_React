// Templating literals

let name="Sarfaraz";
console.log(`${name}`);

console.log(`Name: ${name}`);

console.log(`Length of ${name} is ${name.length}`);

let fullname ="Sarfaraz Hussain";
console.log(fullname);
console.log(fullname.length);
console.log(fullname.toUpperCase());
console.log(fullname.toLowerCase());
console.log(fullname.indexOf('a'));
console.log(fullname.lastIndexOf('a'));
console.log(fullname.substr(1,3));
console.log(fullname.substr(3,4));
console.log(fullname.substr(0,5));