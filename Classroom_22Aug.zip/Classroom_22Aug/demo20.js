// Other way of importing from demo19

var emp = require("./demo18");

var employees = emp.employees;
employees.splice(2,1); // Which index to get the details

for(let e of employees)
    console.log(e)
