module.exports.employees = [
    {"id":1001, "ename":"Sarfaraz","job":"Trainer","salary":5500},
    {"id":1002, "ename":"Hussain","job":"Developer","salary":6500},
    {"id":1003, "ename":"Sohail","job":"Trainer","salary":7500},
    {"id":1004, "ename":"Salman","job":"Programmer","salary":8500}
];