var items = require("./demo16");


for(let fruit of items.fruits)
    console.log(fruit)

for(let veg of items.vegitables)
    console.log(veg)