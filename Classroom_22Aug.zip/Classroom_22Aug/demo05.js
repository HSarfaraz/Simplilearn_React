var d = new Date();

console.log(d);
console.log(d.toLocaleDateString());
console.log(d.toLocaleTimeString());

console.log(d.getDate);
console.log(d.getMonth()+1);
console.log(d.getFullYear());

console.log(d.getHours());
console.log(d.getMinutes());
console.log(d.getSeconds());
console.log(d.getDay());