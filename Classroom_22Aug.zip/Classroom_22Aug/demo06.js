// Display Wishes Based on time
var hour = new Date().getHours();
if(hour<12)
    console.log("Good morning");
else if(hour<16)
    console.log("Good Afternoon");
else 
    console.log("Good evening");


// Day
var day = new Date().getDay()+1;
console.log(day);
switch (day){
    case 1:
        console.log("Sunday");
        break;
    case 2:
        console.log("Monday");
        break;
    case 3:
        console.log("Tuesday");
        break;
    case 4:
        console.log("Wednesday");
        break;
    case 5:
        console.log("Thursday");
        break;
    case 6:
        console.log("Friday");
        break;
    case 7:
        console.log("Saturday");
        break;
}
if(day==1 || day==7)
    console.log("Today is weekend");
else 
    console.log("Today is weekday and busy with office work");