
import React from 'react';
import axios from 'axios';
 
class AxiosDemo01 extends React.Component{
    state={
        students:[],
        url: `http://localhost:3000/students`,
        msg:''
    }
    async getStudents(){        
        var students = [];   
        await axios.get(this.state.url)
            .then( response => students=response.data);
        return students;
    }
    hideStudents(){
        this.setState({students:[]})
    }
    addStudent(){
        var s = {
            "id":Number(this.refs.id.value),
            "sname":this.refs.sname.value,
            "course":this.refs.course.value
        };
        axios.post(this.state.url,s)
            .then( () => this.setState({msg:'Row Added successfully...'}))
            .catch( error => this.setState({msg:error}));
    }
    editStudent(){
        var s = {
            "id":Number(this.refs.id.value),
            "sname":this.refs.sname.value,
            "course":this.refs.course.value
        };
        var url = `${this.state.url}/${s.id}`;
        axios.put(url,s)
        .then( () => this.setState({msg:'Row Edited successfully...'}))
        .catch( error => this.setState({msg:error}));
    }
    deleteStudent(){        
        var id =Number( this.refs.id.value);
        var url = `${this.state.url}/${id}`;
        axios.delete(url)
            .then( () => this.setState({msg:'Row Deleted successfully...'}))
            .catch( error => this.setState({msg:error}));
    }
    render() {  
        return (
            <div>                
                <h1>Consume Web API Demo</h1>
                <button onClick={()=>this.getStudents()
                                        .then(response => this.setState({students:response} ))
                                }>Get All students</button> | 
                <button onClick={()=>this.hideStudents()}>Hide Students</button> <br/>
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr> <th>ID</th> <th>SName</th> <th>Course </th> </tr>
                    </thead>
                    <tbody>
                        { this.state.students.map( s => <tr> <td>{s.id} </td> <td> {s.sname}</td> <td>{s.course}</td> </tr> )}        
                    </tbody>                                
                </table>
                Id: <input type="number" ref="id" /> <button onClick={()=>this.addStudent()}>Add </button> <br/>
                SName: <input type="text" ref="sname" /><button onClick={()=>this.editStudent()}>Edit </button> <br/>
                Cours: <input type="text" ref="course" /> <button onClick={()=>this.deleteStudent()}>Delete </button><br/> {this.state.msg}
            </div>
        );
    }
}
 
export default AxiosDemo01;