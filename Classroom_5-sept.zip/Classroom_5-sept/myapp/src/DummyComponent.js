import React from 'react';
 
class DummyComponent extends React.Component{
    render(){
        return <div>
            <h2>DummyComponent Component</h2>
        </div>
    }
}
export default DummyComponent;
