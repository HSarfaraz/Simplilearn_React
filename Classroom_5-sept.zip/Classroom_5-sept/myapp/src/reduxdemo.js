//step1: Declare store fore redux
var redux = require("redux");
var createStore = redux.createStore;

//Step2: Define actions
const increment = function(){
    return {type:'INCREMENT'};
}
const DECcrement = function(){
    return {type:'DECREMENT'};
}

//Step3; Describe actions with reducer
var reducer = (initialState=0, action) => {
    switch(action.type){
        case "INCREMENT":
            return initialState+1;
        case "DECREMENT":
            return initialState-1;
    }
}

//Step4: Create Store
let store = createStore(reducer);

//Step5: Subscribe store
store.subscribe( ()=> console.log(store.getState()));

//Step 6: Invoke actions
store.dispatch(increment());
store.dispatch(decrement());