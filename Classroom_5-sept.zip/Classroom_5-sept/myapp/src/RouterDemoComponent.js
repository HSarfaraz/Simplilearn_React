
import React from 'react';
import  EmployeeCrud from './EmployeeCrud';
import { BrowserRouter,Route, Switch,Link } from 'react-router-dom';
import FetchDemo03 from './FetchDemo03';
import AxiosDemo01 from './AxiosDemo01';
class RouterDemoComponent extends React.Component{
    render(){
        return <div>
            <BrowserRouter>
            <h2>Routing Demo</h2>
            
            <Link to="/a1">Employee CRUD</Link> | 
            <Link to="/f1">Fetch Demo</Link> | 
            <Link to="/a1">Axios Demo</Link>  <hr/>
            <Switch>
                <Route path="/a1">
                  <EmployeeCrud />
                </Route>
                <Route path="/f1" >
                  <FetchDemo03 />
                </Route>
                <Route path="/a1">
                  <AxiosDemo01 />
                </Route>
            </Switch>
        </BrowserRouter>     
 
        </div>
    }
 
}
 
export default RouterDemoComponent;
