import {store,increment,decrement} from './a1';
import React from 'react';
class A2 extends React.Component{
    state={msg:''};
    componentDidMount(){
        this.setState({msg:store.getState()});
    }
    incrementMethod(){
        store.dispatch(increment());
        this.setState({msg:store.getState()});
    }
    decrementMethod(){
        store.dispatch(decrement());
        this.setState({msg:store.getState()});
    }
    render(){
        return <div>
            <h2>Redux Demo</h2>
            <button onClick={()=>this.incrementMethod()}>Increment</button> 
            <button onClick={()=>this.decrementMethod()}>Decrement</button> <br/>
            Current State: {this.state.msg}
        </div>
    }
}
export default A2;




