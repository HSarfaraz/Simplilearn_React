import React from 'react';
class FetchDemo02 extends React.Component{
    state={s:{},msg:''}
    async getStudentById(){
        var id = Number(this.refs.id.value);
        var  url = `http://localhost:3000/students/${id}`;     
        var student = {};   
        await fetch(url)
            .then( response => response.json())
            .then( response => student=response);
        return student;
    }
    render() { 
        return (
            <div>                
                <h1>Consume Web API Demo</h1>
                ID: <input type="number" ref="id" />  
                <button onClick={()=>this.getStudentById()
                                        .then(response => this.setState({s:response} ))
                                }>Search</button> <br/>
                SName: <input type="text"  value={this.state.s.sname} ref="sname" /> <br/>
                Course: <input type="text"  value={this.state.s.course} ref="course" /> <br/>    
            </div>
        )
    }     

}

export default FetchDemo02;