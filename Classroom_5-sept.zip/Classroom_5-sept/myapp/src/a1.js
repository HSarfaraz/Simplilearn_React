//Step1:        declare store
import { createStore } from 'redux';
 
//Step2:    Create actions
export const increment  = () => {return {type:'INCREMENT'}};
export const decrement = () => {return {type:'DECREMENT'}};
 
//Step3:    Create reducer by describing actions
 
export const  reducer = (InitialState=0, action) => {
    switch(action.type){
        case 'INCREMENT':
            return InitialState+1;
        case 'DECREMENT':
            return InitialState-1;
        default:
                return InitialState;
    }
}
//Step4:    Create store
export let store = createStore(reducer);
 
//Step5:    Subscribe store
store.subscribe(() => console.log(store.getState()));