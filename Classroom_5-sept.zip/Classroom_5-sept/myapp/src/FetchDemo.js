import React from 'react';
class FetchDemo extends React.Component{
    state={students:[],msg:''}
    async getStudents(){
        var  url = "http://localhost:3000/students";     
        var students = [];   
        await fetch(url)
            .then( response => response.json())
            .then( response => students=response);
        return students;
    }
    render() { 
        
        return (
            <div>                
                <h1>Consume Web API Demo</h1>
                <button onClick={()=>this.getStudents().then ( response => this.setState({students : response}))}> Get Employees </button>
            <table className="table table-bordered table-hover">
                <tr>
                    <th>ID</th> <th>SName </th> <th>Course</th>
                </tr>
                { this.state.students.map(s =>  <tr> <td>{s.id}</td><td>{s.sname}</td><td>{s.course}</td>  </tr>) } 
                
                </table>
            </div>
        );
    }
}
export default FetchDemo;