import React from 'react';
import './App.css';
//import  BootstrapDemo from './BootstrapDemo';
//import  EmployeeCrud from './EmployeeCrud';
//import  FetchDemo from './FetchDemo';
//import  FetchDemo02 from './FetchDemo02';
//import  FetchDemo03 from './FetchDemo03';
//import  AxiosDemo01 from './AxiosDemo01';
//import  RouterDemoComponent from './RouterDemoComponent';
//import  LoginComponent from './LoginComponent';
//import A2 from './a2';
import  LoginComponent from './LoginComponent01';

//import ClickCounter from './ClickCounter';
//import HoverCounter from './HoverCounter';
// import ClickCounterHoc from './ClickCounterHoc';
// import HoverCounterHoc from './HoverCounterHoc';

function App() {
  return (
    <div className="App">
      <h2>Root component</h2>
      {/* <BootstrapDemo /> */}
      {/* <EmployeeCrud /> */}
      {/* <FetchDemo /> */}
      {/* <FetchDemo02 /> */}
      {/* <FetchDemo03 /> */}
      {/* <AxiosDemo01 /> */}
      {/* <RouterDemoComponent /> */}
      {/* <LoginComponent /> */}

      {/* <A2 />
 
      <A2 /> */}
      <LoginComponent />

      {/* <ClickCounter />
      <HoverCounter /> */}
      {/* <ClickCounterHoc />
      <HoverCounterHoc /> */}

    </div>
  );
}

export default App;
 