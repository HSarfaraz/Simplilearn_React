import React, { Component } from 'react';
 
class HoverCounter extends Component {
    state={count:0};
    incrementCount(){
        this.setState( previousState => {return {count:previousState.count+1} });
    }
    render() {
        return (
            <div >
                <h1 onMouseOver={()=>this.incrementCount()}>Mouse Hover Counter Component</h1>
                Mouse hover {this.state.count} times
            </div>
        );
    }
}
 
export default HoverCounter;