import React from 'react';
import './App.css'
class BootstrapDemo extends React.Component{
    render  (){
        return (
            <div className="container well">
                <h1>Bootstrap Demo</h1>
                <div class="row">
                    <div class="visible-lg">
                        <h1>Currently Large Screen, You can see 4 columns per row</h1>
                    </div>
                    <div class="visible-md">
                        <h1>Currently Medium Screen, You can see 3 columns per row</h1>
                    </div>
                    <div class="visible-sm">
                        <h1>Currently Small Screen, You can see 2 columns per row</h1>
                    </div>
                    <div class="visible-xs">
                        <h1>Currently Extra Small Screen, You can see 1 columns per row</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="greenBorderClass">
                            <h3>Div1: First Column </h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="greenBorderClass">
                            <h3>Div2:Second Column </h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="greenBorderClass">
                            <h3>Div3: Third Column </h3>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                        <div class="greenBorderClass">
                            <h3>Div4:Fourth Column </h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <input type="submit" class="btn" />
                    <input type="reset" class="btn" />
                    <input type="button" value="click me" class="btn" />
                    <button class="btn btn-default">Default</button>
                    <button class="btn btn-primary">Primary</button>
                    <button class="btn btn-success">Success</button>
                    <button class="btn btn-info">Info</button>
                    <button class="btn btn-warning">Warning</button>
                    <button class="btn btn-danger">Danger</button>
                    <button class="btn btn-link">Link</button>
                </div>

                <div class="row">
                    <ul class="nav nav-tabs">
                        <li><a href="#index" data-toggle="tab">Index</a></li>
                        <li><a href="#about" data-toggle="tab">About</a></li>
                        <li><a href="#contact" data-toggle="tab">Contact</a></li>
                        <li><a href="#login" data-toggle="tab">login</a></li>
                    </ul>
                    
                    <div class="tab-content">
                        <div id="index" class="tab-pane fade">
                            <h1>User Login </h1>
                        </div>
                        <div id="about" class="tab-pane fade">
                            <h1>About</h1>
                        </div>
                        <div id="contact" class="tab-pane fade">
                        <h1>Contact</h1>
                        </div>
                        <div id="login" class="tab-pane fade">
                        <h1>Login </h1>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
 
export default BootstrapDemo;
