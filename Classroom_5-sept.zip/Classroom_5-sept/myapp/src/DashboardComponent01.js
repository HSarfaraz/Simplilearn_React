
import React from 'react';
 
class DashboardComponent extends React.Component{
    render(){
        return <div>
            <h2>Dashboard Component</h2>
            Hello user, welcome to dashboard
        </div>
    }
}
export default DashboardComponent;

