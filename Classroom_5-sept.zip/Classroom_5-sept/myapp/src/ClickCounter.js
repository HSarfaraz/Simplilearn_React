import React from 'react';
class ClickCounter extends React.Component {
    state={count:0}
    increment(){
        this.setState( previousState => {return {count:previousState.count+1} });
    }
    render() {
        return (
            <div>
                <h1>Button Click Counter Component</h1>
                <button onClick={()=>this.increment()}>Increment</button>  <br/> 
                
                Counter Value: {this.state.count}
            </div>
        );
    }
}
export default ClickCounter;



 


