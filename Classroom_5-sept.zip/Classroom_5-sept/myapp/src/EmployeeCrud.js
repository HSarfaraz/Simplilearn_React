import React from 'react';
 
class EmployeeCrud extends React.Component{
    constructor(){
        super();
        this.state={
            employees:[
                {"id":1001,"ename":"Anil","job":"Developer","salary":5500},
                {"id":1002,"ename":"Bobby","job":"Programmer","salary":5900},
                {"id":1003,"ename":"Cathe","job":"Developer","salary":5300},
                {"id":1004,"ename":"David","job":"Trainer","salary":5100}
            ],
            emp:{},msg:''
        };
        
    }
    
    getRowById(id){
        this.setState({emp:this.state.employees.find(x=>x.id==id)});
        
    }
    deleteRowByid(id){
        var employees = this.state.employees;
        var index = employees.findIndex(x=>x.id==id);
        if ( window.confirm ("Are you sure?"))
            employees.splice(index,1);
        this.setState({employees:employees});
    }
    addEmployee(){
            var employees = this.state.employees;
            var emp = {id:this.refs.id.value,
                        ename: this.refs.ename.value,
                    job: this.refs.job.value,
                salary:this.refs.salary.value
            };
            employees.push(emp);
            this.setState({employees:employees});
    }
    clearAll(){
        this.setState( { emp: {} });
    }
    editEmployee(){
        var id = this.refs.id.value;
        var index = this.state.employees.findIndex(x=>x.id==id);
        var emp = {
            id:id,
            ename:this.refs.ename.value,
            job:this.refs.job.value,
            salary:this.refs.salary.value
        };
        var employees = this.state.employees;
        employees[index]=emp;
        this.setState({employees:employees})
    }
    render() {
        var employees = this.state.employees;
        return (
            <div className="container">
                <h2>List of Employees</h2>
                 Message: {`Count is : ${this.state.employees.length}`} <hr/>
                 <table className="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>ID</th> <th>EName</th>  <th>Gender</th> <th>Age</th> <th>Operations</th>
                    </tr></thead>
                    <tbody>
                    {employees.map(e=>                    
                         <tr>
                        <td>{e.id}</td>     <td>{e.ename}</td>     <td>{e.job}</td>     <td>{e.salary}</td> 
                        <td><a href="#" onClick={()=>this.getRowById(e.id)}>Select</a> |
                            <a href="#" onClick={()=>this.deleteRowByid(e.id)}>Delete</a> </td>
                    </tr>
                        )}
                        </tbody>
                </table>   
                ID: <input type="number" ref="id" value={this.state.emp.id} /> <button onClick={()=>this.addEmployee()}>Add</button> <br/>  
                Ename: <input type="text" ref="ename"  value={this.state.emp.ename} /> <br/>
                Job: <input type="text" ref="job" value={this.state.emp.job} /> <br/>
                Salary: <input type="number" ref="salary" value={this.state.emp.salary}  /> <br/>
                <button onClick={()=>this.clearAll()}>Clear All </button> 
                <button onClick={()=>this.editEmployee()}>Edit Employee</button>
            </div>
        );
    }
}
export default EmployeeCrud;