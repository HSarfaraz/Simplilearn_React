class DemoHello extends Component {
    constructor(){
      super();
      this.uname = React.createRef();
    }
  Display(){
    var uname = this.uname.current.value;
    document.getElementById("span1").innerHTML="Hi " +uname;
  }
    render(){        
        return (
            <div> 
                <h2>Input Demo </h2>
                Enter Name: <input type="text" ref={ this.uname} /> <br/>
                <button onClick={()=>this.Display()}>Display</button>
                <span id="span1"> </span>
            </div>
        );
    }
  }
  