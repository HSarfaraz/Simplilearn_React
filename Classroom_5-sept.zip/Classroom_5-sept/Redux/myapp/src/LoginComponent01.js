import React from 'react';
import {Redirect, BrowserRouter,Route} from 'react-router-dom';
import DashboardComponent from './DashboardComponent';
class LoginComponent extends React.Component{
    state={
        msg:'',
        users:[
            {'uname':'sarfaraz','pwd':'sarfaraz'},
            {'uname':'gopi','pwd':'gopi'},
            {'uname':'arpit','pwd':'arpit'},
            {'uname':'hari','pwd':'hari'}
        ],
        status:false
    };
        
    validate(){
        var uname = this.refs.uname.value;  
        var pwd = this.refs.pwd.value;
        if (  this.state.users.find( x=>x.uname==uname && x.pwd==pwd ) ){                        
            this.setState({status:true});
        }
        else{
            this.setState({msg:'Invalid input credentials...'});
        }
    }
    render() {
        if ( this.state.status==true)
            return <div>
            <BrowserRouter>
                <Redirect to="/dashboard" />
 
                <Route path="/dashboard">
                  <DashboardComponent />
                </Route>
            </BrowserRouter>
            </div>
        return (
            <div className={this.state.class1}>
                <h2>User Login</h2>
 
                <input type="text" placeholder="User Name" ref="uname" /> <br />
                <input type="password" placeholder="Password" ref="pwd" /> <br/>
                <button onClick={()=>this.validate()}>Login</button> <hr/>
                {this.state.msg} <br/>
            
            </div>
        );
    }
}
export default LoginComponent;
