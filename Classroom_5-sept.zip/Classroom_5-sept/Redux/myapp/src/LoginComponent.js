import React from 'react';
import {store,login,logout} from './sessionStore';
import DashboardComponent from './DashboardComponent01';
import DummyComponent from './DummyComponent';
class LoginComponent extends React.Component{
    state={
        msg:'',
        users:[
            {'uname':'sarfaraj','pwd':'sarfaraj'},
            {'uname':'gopi','pwd':'gopi'},
            {'uname':'arpit','pwd':'arpit'},
            {'uname':'hari','pwd':'hari'}
        ],
        status:'invalid'
    };
        
    validate(){
        var uname = this.refs.uname.value;  
        var pwd = this.refs.pwd.value;
        if (  this.state.users.find( x=>x.uname==uname && x.pwd==pwd ) ){
            store.dispatch(login(uname));
            this.setState({msg:'Credentials Validate and found correct', class1:'successClass',status:'valid'});
        }
        else{
            store.dispatch(logout());
        this.setState({msg:'Invalid input Credentials ', class1:'failureClass',status:'invalid'});        
        }
    }
    render() {
        return (
            <div className={this.state.class1}>
                <h2>User Login</h2>
 
                <input type="text" placeholder="User Name" ref="uname" /> <br />
                <input type="password" placeholder="Password" ref="pwd" /> <br/>
                <button onClick={()=>this.validate()}>Login</button> <hr/>
                {this.state.msg} <br/>
        {  this.state.status=='valid' ? <DashboardComponent /> : <DummyComponent />      }
            </div>
        );
    }
}
export default LoginComponent;