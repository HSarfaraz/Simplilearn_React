import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
//import MyComponent1 from './MyComponent1';
import DisplayComponent from './DisplayComponent';
// var headerElement = <div><h1>Header Element </h1><p>This is my paragraph</p></div>;
// ReactDOM.render( headerElement, document.getElementById("root"));

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

//1-10th way
//ReactDOM.render( <MyComponent1 />, document.getElementById('root'));
//11th way
//ReactDOM.render( <DisplayComponent msg="Hello Sarfaraz Ji"/>, document.getElementById('root'));
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
