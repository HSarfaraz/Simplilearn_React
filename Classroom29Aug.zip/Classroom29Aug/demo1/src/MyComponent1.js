import React from 'react';

function MyComponent1(){
    
    // 1st way

    // var jsx = 
    //     <div>
    //         <h1>My first functional component</h1>;
    //         <p>My first paragraph</p>
    //     </div>;
    // return jsx;

    // 2nd way

    // return( 
    //     <div>
    //         <h1>My first functional component</h1>
    //         <p>My first paragraph</p>
    //         <p>My second paragraph</p>
    //     </div>
    // );

    // 3rd way

    // return( 
    //     <div>
    //         <h1>My first calculation component</h1>
    //         {10*9}
    //     </div>
    // );

    // 4th way

    // var heading = 'My heading';
    // var msg = "my first paragraph"
    // return( 
    //     <div>
    //         <h1>{heading}</h1>
    //         <p>{msg}</p>
    //     </div>
    // );

    // 5th way

    // var heading = 'json in jsx';
    // var Emp = {"id":1000,"ename":"Sarfaraz","salary":550000}
    // return( 
    //     <div>
    //         <h1>{heading}</h1>
    //         <p>{Emp.id}</p>
    //         <p>{Emp.key}</p>
    //         <p>{Emp.ename}</p>
    //         <p>{Emp.salary}</p>
    //         {/* <p>{Emp}</p> */}
    //     </div>
    // );


    // 6th way

    // var heading = "json in jsx";
    // var fruits = ['Apple','Banana','Pomegranate']

    // //map is used to iterate
    // return( 
    //     <div>
    //         <h1>{heading}</h1>
    //         <ol>{fruits.map(fruit => <li> {fruit} </li>) }</ol>
    //     </div>
    // );


    // 7th way

    // var heading = "json in jsx";
    // var fruits = ['Apple','Banana','Pomegranate'];
    // var vegetables = ['Onion','Potato','Tomato','Beans']

    // //map is used to iterate
    // return( 
    //     <div>
    //         <h1>{heading}</h1>
    //         <table border="1">
    //             <tr>
    //                 <th>Item</th>
    //                 <th>Length</th>
    //                 <th>Uppercase</th>
    //                 <th>Lowercase</th>
    //             </tr>
    //             {fruits.map(fruit=>
    //             <tr>
    //                 <td>{fruit}</td>
    //                 <td>{fruit.length}</td>
    //                 <td>{fruit.toUpperCase()}</td>
    //                 <td>{fruit.toLowerCase()}</td>
    //             </tr>
    //             )}
    //         </table>
    //     </div>
    // );


    //8th way
    // var heading = "json in jsx";
    // var names = ['Suresh','Ramesh','Kamlesh'];

    // return( 
    //     <div>
    //         <h1>{heading}</h1>
    //         <table border="1">
    //             <tr>
    //                 <th>name</th>
    //                 <th>Length</th>
    //                 <th>first name</th>
    //                 <th>last name</th>
    //             </tr>
    //             {names.map(name=>
    //             <tr>
    //                 <td>{name}</td>
    //                 <td>{name.length}</td>
    //                 <td>{name.substr(0,name.indexOf(' '))}</td>
    //                 <td>{name.substr(name.lastIndexOf(''))}</td>
    //             </tr>
    //             )}
    //         </table>
    //     </div>
    // );

    //9th way
    //Display employee records in jsx
    // var employees = [
    //     {"id":1000,"ename":"Sarfaraz","job":"Developer","Salary":55000},
    //     {"id":2000,"ename":"Hussain","job":"Tester","Salary":25000},
    //     {"id":3000,"ename":"Kamran","job":"DevOps","Salary":35000},
    // ]
    // return(
    //     <div>
    //         <table border="1">
    //             <tr>
    //                 <th>Employee ID</th>
    //                 <th>Employee Name</th>
    //                 <th>Employee Salary</th>
    //             </tr>
    //             {employees.map(emp=>
    //             <tr>
    //                 <td>{emp.id}</td>
    //                 <td>{emp.ename}</td>
    //                 <td>{emp.Salary}</td>
    //             </tr>
    //             )}
    //         </table>
    //     </div>
    // );


    //10th way

    // var employees = [
    //     {"id":1000,"ename":"Sarfaraz","job":"Developer","Salary":55000},
    //     {"id":2000,"ename":"Hussain","job":"Tester","Salary":25000},
    //     {"id":3000,"ename":"Kamran","job":"DevOps","Salary":35000},
    // ]   
};

// 10th way
// function showEmployees(heading,employees){
//     return(
//         <div>
//             <table border="1">
//                 <tr>
//                     <th>Employee Name</th>
//                     <th>Employee Job</th>
//                     <th>Employee Salary</th>
//                 </tr>
//                 {employees.map(emp=>
//                 <tr>
//                     <td>{emp.ename}</td>
//                     <td>{emp.job}</td>
//                     <td>{emp.Salary}</td>
//                 </tr>
//                 )}
//             </table>
//         </div>
//     );
}

export default MyComponent1;
