import React from 'react';

function DisplayComponent(props){
    return <div>
            <h2>Display Component</h2>
            Message: {props.msg}
        </div>
}

export default DisplayComponent;