import React from 'react';

function AdditionComponent(props){
    return(
        <div>
            Addition of {props.a},{props.b} is { Number(props.a) + Number(props.b)}
        </div>
    )
}

export default AdditionComponent;