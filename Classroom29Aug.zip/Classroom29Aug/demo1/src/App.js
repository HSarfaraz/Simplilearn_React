import React from 'react';
import logo from './logo.svg';
import './App.css';
// import DisplayComponent from './DisplayComponent';
// import SquareComponent from './SquareComponent';
// import AdditionComponent from './AdditionComponent';
// import AdditionComponent from './AdditionComponent';
// import EmployeeList from './EmployeeList';
//import Component1 from './Component1';
import MyComponent2 from './MyComponent2';

function App() {

  // var fruits = ['Apple','Banana','Kiwi','Oranges'];
  // var vegetables = ['Onion','Potato','Tomato','Beans'];

  //  var employees = [
  //    {"id":1001,"ename":"Anil","job":"Admin","salary":11000},
  //    {"id":1002,"ename":"Hussain","job":"Developer","salary":11000},
  //    {"id":1003,"ename":"David","job":"Clerk","salary":11000},
  //    {"id":1004,"ename":"George","job":"Developer","salary":11000},
  //    {"id":1005,"ename":"Anil","job":"Clerk","salary":11000},
  //    {"id":1006,"ename":"Anil","job":"Admin","salary":11000},
  //  ]

  return (
    <div>
        <h1>Root Component</h1>
        {/* <DisplayComponent msg="Hello"/>
        <DisplayComponent msg="Hi"/> */}
        {/* <SquareComponent n="5"/>
        <SquareComponent n="20"/>
        <AdditionComponent a="20" b="30"/> */}

        {/* <ItemsComponents items={fruits} headings="List of Fruits"/>
        <ItemsComponents items={vegetables} headings="List of Vegitables"/> */}

        {/* <EmployeeList employees={employees} categaory="All"/>
        <EmployeeList employees={employees.filter(x=>x.job=="Clerk")} categaory="Clerk"/>
        <EmployeeList employees={employees.filter(x=>x.job=="Developer")} categaory="Developer"/> */}

        {/* <Component1 /> */}
        <MyComponent2 name="Sarfaraz" age="34" gender="male"/>
        <MyComponent2 name="Katrina" age="36" gender="female"/>
        <MyComponent2 name="Kamran" age="29" gender="male"/>

    </div>
  );
}

export default App;
