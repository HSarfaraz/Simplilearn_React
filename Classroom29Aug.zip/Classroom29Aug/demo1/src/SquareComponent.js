import React from 'react';

function SquareComponent(props){
    return(
        <div>
            Square {props.n} is {props.n*props.n}
        </div>
    )
}

export default SquareComponent;