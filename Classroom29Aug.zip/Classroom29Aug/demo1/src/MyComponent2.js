import React from 'react';

class MyComponent2 extends React.Component{
    render(){
        return(
            <div>
                <h1>My Component</h1>
                Properties: {JSON.stringify(this.props)}
            </div>
        )
    }
}

export default MyComponent2;