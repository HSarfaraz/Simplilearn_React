import React from 'react';

class Component1 extends React.Component{
    render(){
            var jsx = <h1>Class component</h1>
            return jsx;
    }
}

export default Component1;