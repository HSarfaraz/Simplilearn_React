import React from 'react';

function ItemsComponent(props){
    return(
        <div>
            <h1>{props.headings}</h1>
            <ol>
                {props.items.map(x=> <li>{x}</li>)}
            </ol>

            {`Item count is: ${props.items.length}`}

        </div>
    )
}

export default ItemsComponent;