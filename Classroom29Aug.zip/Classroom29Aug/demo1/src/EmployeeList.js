import React from 'react';

function EmployeeList(props){
    var employees = props.employees;
    var category = props.category;

    return(
        <div>
            <table border="1">
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Salary</th>
                </tr>
                { employees.map(e => 
                <tr>
                    <td>{e.id}</td>
                    <td>{e.ename}</td>
                    <td>{e.salary}</td>
                </tr>
                )}
            </table>
        </div>
    )
}

export default EmployeeList;