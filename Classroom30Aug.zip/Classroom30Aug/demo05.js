function display1(){
    setInterval(() =>{
        console.log("Hello from display 1")
    }, 500);
}
function display2(){
    setInterval(() =>{
        console.log("Hello from display 2")
    }, 500);
}

function display(cb){
    cb();
}

display(display1);
display(display2);