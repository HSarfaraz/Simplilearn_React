var status = true;

let promise1 = new Promise(function(request, resolve){
    if(status)
        request("Hello from request");
    else
        resolve("Hello from reject");
});

console.log(promise1);