function square(n){
    return n*n;
}

var cube = x => x*x*x;

function calcNumber(n,cb){
    return cb(n);
}

console.log(square(3));