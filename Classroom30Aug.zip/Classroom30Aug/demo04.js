var add = (a,b) => a+b;
var big = (a,b) => a>b?a:b;

var calc =(a,b,cb) => cb(a,b);


console.log(calc(5,8,add));
console.log(calc(5,8,big));
