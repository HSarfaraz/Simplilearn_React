//Callback example

function display1(){
    console.log("Hello from deisplay 1")
}
function display2(){
    console.log("Hello from deisplay 2")
}

function display(cb){
   cb();
}

display(display1);
display(function(){
    console.log("Anonymus function defination")
});

display( ()=> console.log("Hello function from arrow function"));
