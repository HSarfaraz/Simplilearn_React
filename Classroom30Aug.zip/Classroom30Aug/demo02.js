function displayName(name){
    console.log(`Hello ${name}`);
}

var fname = name => console.log(`First Name:${name.substr(0,name.indexOf(' '))}`);


function display(name, cb){
    cb(name);
}

display("Sarfaraz",displayName);
display("Hussain",fname);
