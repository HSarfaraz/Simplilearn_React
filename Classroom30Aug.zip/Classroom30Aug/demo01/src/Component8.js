import React from 'react';

class Component8 extends React.Component{
    state = {m:0,p:0,c:0,tot:0,avg:0,result:'',grade:''};

    square(){
        var m = Number(this.refs.m.value);
        var p = Number(this.refs.p.value);
        var c = Number(this.refs.c.value);

        var tot = Number(s1)+Number(s2)+Number(s3);
        var avg = tot / 3;
        this.setState({tot:tot,avg:avg});

        if(m>=35 && c>=35 && p>=35){
            this.setState({result:'PASS'});

            if(avg>=75) this.setState({grade:'A1'});
            else if(avg>=60) this.setState({grade:'A'});
            else if(avg>=50) this.setState({grade:'B'});
            else this.setState({grade:'C'});
        }else{
            this.setState({result:'FAIL'});
            this.setState({grade:'NA'});
        }

       
    }
  
    render(){
        return <div>
            <h2>State property Demo</h2>
            Enter Name:
            Math: <input type="number" ref="m" />
            Physics: <input type="number" ref="p" />
            Chemistry:<input type="number" ref="c" />
            <button onClick={()=> this.display() }>display</button>
            {this.state.msg}
        </div>
    }
}

export default Component8;