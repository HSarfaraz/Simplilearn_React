import React from 'react';

class Component1 extends React.Component{
    state = {msg:'Hellow from state message'};

    render(){
        return <div>
            <h2>State property</h2>
            {this.state.msg}
        </div>
    }
}

export default Component1;