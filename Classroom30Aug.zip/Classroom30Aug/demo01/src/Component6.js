import React from 'react';

class Component6 extends React.Component{
    state = {msg:''}

    wishes(){
        var name = this.refs.t1.value;
        var msg = '';
        var hour = new Date().getHours();

        if(hour<12) msg='Good morning';
        else if(hour<16) msg='Good afternoon';
        else msg='Good evening';

        this.setState({msg:msg +=name});
    }
  
    render(){
        return <div>
            <h2>State property Demo</h2>
            Enter Name:
            <input type="text" ref="t1" />
            <button onClick={()=> this.wishes() }>say Hello</button>
            {this.state.msg}
        </div>
    }
}

export default Component6;