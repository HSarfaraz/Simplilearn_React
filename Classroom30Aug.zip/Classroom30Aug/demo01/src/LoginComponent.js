import React from 'react';

class LoginComponent extends React.Component{

    state={
            msg:'',
            users:[
                {"uname":"sarfaraz","pwd":"sarfaraz"},
                {"uname":"hari","pwd":"hari"},
                {"uname":"gopal","pwd":"gopal"},
            ]

        }
    validate(){
        var uname = this.refs.uname.value;
        var pwd = this.refs.pwd.value;

        // if(uname == "sarfaraz" && pwd=="sarfaraz")
        if(this.state.users.find(x=>x.uname==uname && x.pwd==pwd))
            this.setState({msg:'Credetials Validate and found correct', class1:'successClass'});
        else
        this.setState({msg:'Invalid input Credetials', class1:'failureClass'});
    }

    render(){
        return(
            <div className={this.state.class1}>
            <h2>User Login</h2>

                <input type="text" placeholder="User Name" ref="uname" /><br />
                <input type="password" placeholder="Password" ref="pwd" /><br />

                <button onClick={ ()=> this.validate()}>Login</button>
                <hr/>
                {this.state.msg}
            </div>
        );
    }
}

export default LoginComponent;