import React from 'react';

class Component5 extends React.Component{
    state = {msg:''}

    getMessage(p){
        if(p=="date")
            this.setState({msg:`Date is: ${new Date().toLocaleDateString()}`});
        else if(p=="time")
            this.setState({msg:`Time is: ${new Date().toLocaleTimeString()}`});
    }

  
    render(){
        return <div>
            <h2>State property Demo</h2>
            <button onClick={()=> this.getMessage("date") }>Date</button>
            <input type="button" value="time" onClick={()=> this.getMessage("time")} />
            {this.state.msg}
        </div>
    }
}

export default Component5;