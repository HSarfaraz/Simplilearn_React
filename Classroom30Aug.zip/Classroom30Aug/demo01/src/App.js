import React from 'react';
import './App.css';
//import Component1 from './Component1';
//import Component2 from './Component2';
//import Component3 from './Component3';
//import Component4 from './Component4';
//import Component5 from './Component5';
//import Component6 from './Component6';
//import Component7 from './Component7';
//import LoginComponent from './LoginComponent';
//import RadioButtonComponent from './RadioButtonComponent';
//import CheckBoxComponent from './CheckBoxComponent';
//import DropdownList from './DropdownList';
import EmployeeCrud from './EmployeeCrud';

function App() {
  return (
    <div>
      <h1>Root Component</h1>
      {/* <Component1 /> */}
      {/* <Component2 /> */}
      {/* <Component3 /> */}
      {/* <Component4 /> */}
      {/* <Component5 /> */}
      {/* <Component6/> */}
      {/* <Component7/>
      <Component8/> */}
      {/* <LoginComponent /> */}
      {/* <RadioButtonComponent /> */}
      {/* <CheckBoxComponent /> */}
      {/* <DropdownList /> */}
      <EmployeeCrud />
    </div>
  );
}

export default App;
