import React from 'react';

class Component2 extends React.Component{

    render(){
        return <div>
            <h2>State property Demo</h2>
            <input type="button" value="Hi" onClick={ ()=> alert("Hi")} />
            <button onClick={()=> alert("Hello")}>say ello</button>
        </div>
    }
}

export default Component2;