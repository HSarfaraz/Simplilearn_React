import React from 'react';

class DropdownList extends React.Component{
    state={msg:'',direction:''}
    sayHello(){
        var direction = this.refs.direction.value;
        this.setState({msg:direction});
    }

    render(){
        return(
            <div>
                <select ref="direction">
                    <option value="North">North</option>
                    <option value="South">South</option>
                </select>
                <button onClick={()=>this.sayHello()}>sayHello</button>
                {this.state.msg}
            </div>
        )
    }
}

export default DropdownList;