import React from 'react';

class Component3 extends React.Component{
    state = {msg:''}
    render(){
        return <div>
            <h2>State property Demo</h2>
            <button onClick={()=> this.setState({msg:'Hello'}) }>say Hello</button>
            <button onClick={()=> this.setState({msg:''}) }>Clear Message</button>
            {this.state.msg}
        </div>
    }
}

export default Component3;