import React from 'react';

class RadioButtonComponent extends React.Component{

    state = {gender:'',msg:''}
    changeGender(event){
        this.setState({gender:event.target.value});
    }

    display(){
        var name = this.refs.name.value;
        var gender = this.state.gender;

        if(gender == 'male')
            this.setState({msg:`Hello Mr. ${name}`})
        else if(gender == 'female')
            this.setState({msg:`Hello Miss. ${name}`})
    }
    render(){
        return(
            <div>
                <h2>Radio Button Demo</h2>
                Enter Name: <input tupe="text" ref="name" /><br />
                Choose Gender:
                <input type="radio" name="gender" value="male" onChange={ (event)=> this.changeGender(event)} />Male
                <input type="radio" name="gender" value="female" onChange={ (event)=> this.changeGender(event)} />Female <br />
                <button onClick={ ()=> this.display()}>Display</button>
                <hr/>
                {this.state.msg}
            </div>
        )
    }
}

export default RadioButtonComponent;