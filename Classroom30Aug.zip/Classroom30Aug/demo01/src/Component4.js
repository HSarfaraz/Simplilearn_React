import React from 'react';

class Component4 extends React.Component{
    state = {msg:''}

    sayHello(){
        this.setState({msg:'Hello'});
    }

    clearMessage(){
        this.setState({msg:''});
    }
    render(){
        return <div>
            <h2>State property Demo</h2>
            <button onClick={()=> this.sayHello() }>say Hello</button>
            <button onClick={()=> this.clearMessage()}>Clear Message</button>
            {this.state.msg}
        </div>
    }
}

export default Component4;