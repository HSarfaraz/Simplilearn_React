import React from 'react';

class Component6 extends React.Component{
    state = {msg:''}

    square(){
        var n = Number(this.refs.t1.value);
        var msg = `Square of ${n} is ${n*n}`;
        this.setState({msg:msg });
    }
  
    render(){
        return <div>
            <h2>State property Demo</h2>
            Enter Name:
            <input type="number" ref="t1" />
            <button onClick={()=> this.square() }>square</button>
            {this.state.msg}
        </div>
    }
}

export default Component6;