import React from 'react';

class CheckBoxComponent extends React.Component{
    constructor(){
        super();
        this.state={msg:''};
    }

    display(e){
        if(e.target.checked)
            this.setState({msg:'Thanks for accepting terms'});
        else
            this.setState({msg:'Please read and accept terms'});
    }

    render(){
        return(
            <div>
                <h1>Checkbox Component</h1>
                <input type="checkbox" onChange = { (e)=> this.display(e)} />
                    Terms and conditions <br />
                    {this.state.msg}
            </div>
        )
    }
}

export default CheckBoxComponent;